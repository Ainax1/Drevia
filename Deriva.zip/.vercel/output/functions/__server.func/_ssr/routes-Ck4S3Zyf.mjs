import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as saveApps, i as localInvent, n as PIGMENT_CLASS, r as loadApps, s as sourceLine, t as KIND_LABEL } from "./model-Bco1kWyr.mjs";
import { a as object, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as List, c as Feather, d as Clock, f as CircleHelp, i as Play, l as Eye, n as Square, o as Hourglass, p as Check, r as Quote, s as Hash, u as Dices } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Ck4S3Zyf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({
	mode: _enum(["apps", "ideas"]),
	avoid: array(string().max(40)).max(40)
});
var inventWave = createServerFn({ method: "POST" }).validator((input) => Input.parse(input)).handler(createSsrRpc("2dc49426ecc7e71ddcae9d3babf12503c15044033d55e6fc4efd9fedc1c9ad37"));
var ICONS = {
	frase: Quote,
	dado: Dices,
	cuenta: Hash,
	lista: List,
	pregunta: CircleHelp,
	reloj: Clock,
	oraculo: Eye
};
function Phone() {
	const [apps, setApps] = (0, import_react.useState)([]);
	const [ideas, setIdeas] = (0, import_react.useState)([]);
	const [ideasOpen, setIdeasOpen] = (0, import_react.useState)(false);
	const [mode, setMode] = (0, import_react.useState)("espera");
	const [queue, setQueue] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)("En espera. Todavía no ha empezado.");
	const [source, setSource] = (0, import_react.useState)(null);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [arrived, setArrived] = (0, import_react.useState)(null);
	const [now, setNow] = (0, import_react.useState)(null);
	const gen = (0, import_react.useRef)(0);
	const hydrated = (0, import_react.useRef)(false);
	const appsRef = (0, import_react.useRef)(apps);
	appsRef.current = apps;
	(0, import_react.useEffect)(() => {
		const stored = loadApps();
		if (stored.length > 0) {
			setApps(stored);
			setNotice("En espera. Lo de antes sigue en el teléfono.");
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated.current) {
			hydrated.current = true;
			return;
		}
		saveApps(apps);
	}, [apps]);
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(/* @__PURE__ */ new Date());
		tick();
		const id = window.setInterval(tick, 3e4);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		if (mode !== "marcha" || queue.length === 0) return;
		const next = queue[0];
		if (!next) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const timer = window.setTimeout(() => {
			const prev = appsRef.current;
			if (prev.length >= 9) {
				setQueue([]);
				setMode("espera");
				setNotice("Está lleno. Entra en una app y quítala.");
				return;
			}
			const duplicate = prev.some((app) => app.name.toLowerCase() === next.name.toLowerCase());
			if (!duplicate) {
				setApps((current) => current.some((app) => app.id === next.id) ? current : [...current, next]);
				setArrived(next.id);
			}
			setQueue((current) => current.slice(1));
			setNotice(duplicate ? `«${next.name}» ya estaba.` : `Puso «${next.name}». ${sourceLine(source)}`);
			if (queue.length === 1) setMode("espera");
		}, reduce ? 0 : 1100);
		return () => window.clearTimeout(timer);
	}, [
		mode,
		queue,
		source
	]);
	async function ask(kind) {
		const token = ++gen.current;
		setBusy(true);
		if (kind === "ideas") setIdeasOpen(true);
		const avoid = appsRef.current.map((app) => app.name);
		let result = {
			apps: [],
			source: "aparato"
		};
		try {
			const remote = await inventWave({ data: {
				mode: kind,
				avoid
			} });
			if (gen.current !== token) return;
			if (remote.ok && remote.apps.length > 0) result = {
				apps: remote.apps,
				source: "ia"
			};
		} catch {
			if (gen.current !== token) return;
		}
		if (result.apps.length === 0) result = {
			apps: localInvent(avoid, 4),
			source: "aparato"
		};
		if (gen.current !== token) return;
		setBusy(false);
		setSource(result.source);
		const via = sourceLine(result.source);
		if (result.apps.length === 0) {
			setNotice("No se le ocurrió nada nuevo.");
			return;
		}
		if (kind === "ideas") {
			setIdeas(result.apps);
			setNotice(`Ideas listas. Nada instalado. ${via}`);
			return;
		}
		setIdeasOpen(false);
		setOpenId(null);
		setQueue(result.apps);
		setMode("marcha");
		setNotice(`Ya eligió ${result.apps.length}. ${via}`);
	}
	function onIniciar() {
		setIdeasOpen(false);
		setOpenId(null);
		if (apps.length >= 9) {
			setNotice("Está lleno. Entra en una app y quítala.");
			setMode("espera");
			return;
		}
		if (queue.length > 0) {
			setMode("marcha");
			setNotice("Sigue con lo que ya había elegido.");
			return;
		}
		ask("apps");
	}
	function onParar() {
		gen.current += 1;
		setBusy(false);
		setQueue([]);
		setMode("parado");
		setNotice("Parado. No va a poner nada más.");
	}
	function onEsperar() {
		gen.current += 1;
		setBusy(false);
		setMode("espera");
		setNotice(queue.length > 0 ? "En espera. Lo que faltaba no se instala hasta que inicies." : "En espera. No hace nada.");
	}
	function put(app) {
		if (apps.some((item) => item.name.toLowerCase() === app.name.toLowerCase())) {
			setNotice(`«${app.name}» ya está en el teléfono.`);
			return;
		}
		if (apps.length >= 9) {
			setNotice("Está lleno. Quita una antes.");
			return;
		}
		setApps((current) => [...current, app]);
		setArrived(app.id);
		setIdeasOpen(false);
		setNotice(`Pusiste «${app.name}».`);
	}
	function patch(next) {
		setApps((current) => current.map((app) => app.id === next.id ? next : app));
	}
	function remove(id) {
		setApps((current) => current.filter((app) => app.id !== id));
		setOpenId(null);
		setNotice("Quitada. El hueco queda libre.");
	}
	const open = apps.find((app) => app.id === openId) ?? null;
	const clock = now ? now.toLocaleTimeString("es", {
		hour: "2-digit",
		minute: "2-digit"
	}) : "––:––";
	const modeLabel = busy && ideasOpen ? "Pensando ideas" : busy ? "Eligiendo" : ideasOpen ? "Ideas" : mode === "marcha" ? queue.length > 0 ? `En marcha · ${queue.length}` : "En marcha" : mode === "parado" ? "Parado" : "En espera";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-desk text-ink md:grid md:place-items-center md:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "device mx-auto flex w-full max-w-md flex-col overflow-hidden bg-paper font-sans md:border md:border-line md:shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden justify-center pt-3 md:flex",
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-16 rounded-full bg-bone" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between px-5 pt-4 pb-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
							className: "w-16 text-sm tabular-nums",
							dateTime: now?.toISOString(),
							children: clock
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg leading-none",
							children: "Deriva"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex w-16 items-end justify-end gap-1",
							"aria-hidden": true,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "block h-2 w-1 rounded-full bg-ink" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "block h-2.5 w-1 rounded-full bg-ink" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: `block h-3 w-1 rounded-full ${mode === "marcha" ? "bg-copper motion-safe:animate-pulse" : "bg-muted"}` })
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "inline-flex items-center gap-2 rounded-full bg-bone px-3 py-1 text-xs text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-1.5 rounded-full ${mode === "marcha" ? "bg-copper" : "bg-muted"}` }), modeLabel]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						"aria-live": "polite",
						children: notice
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 overflow-y-auto",
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenApp, {
						app: open,
						onBack: () => setOpenId(null),
						onRemove: () => remove(open.id),
						onChange: patch
					}) : ideasOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ideas, {
						ideas,
						busy,
						onPut: put,
						onClose: () => setIdeasOpen(false)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$1, {
						apps,
						arrived,
						onOpen: setOpenId
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dock border-t border-line bg-paper px-3 pt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
								label: "Iniciar",
								icon: Play,
								pressed: mode === "marcha" || busy && !ideasOpen,
								emphasize: apps.length === 0 && mode !== "marcha" && !ideasOpen,
								disabled: busy,
								onClick: onIniciar
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
								label: "Parar",
								icon: Square,
								pressed: mode === "parado",
								onClick: onParar
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
								label: "Esperar",
								icon: Hourglass,
								pressed: mode === "espera" && !busy && !ideasOpen,
								onClick: onEsperar
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
								label: "Ideas",
								icon: Feather,
								pressed: ideasOpen,
								disabled: busy,
								onClick: () => void ask("ideas")
							})
						]
					})
				})
			]
		})
	});
}
function DockButton({ label, icon: Icon, pressed, emphasize, disabled, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": pressed,
		disabled,
		onClick,
		className: `flex min-h-14 flex-1 flex-col items-center justify-center gap-1 rounded-2xl text-xs font-medium disabled:opacity-50 ${pressed ? "bg-ink text-paper" : "bg-bone text-ink"} ${emphasize && !pressed ? "ring-2 ring-copper" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4",
			"aria-hidden": true
		}), label]
	});
}
function Home$1({ apps, arrived, onOpen }) {
	if (apps.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-6 pt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl leading-tight",
				children: "Nada todavía."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xs text-base leading-relaxed",
				children: "Este teléfono se inventa sus propias apps. Iniciar lo pone en marcha. Esperar lo deja quieto. Ideas propone, sin instalar nada."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 max-w-xs text-sm leading-relaxed text-muted",
				children: "Solo cambia lo que hay dentro de esta pantalla. El resto de tu teléfono sigue igual."
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid grid-cols-3 gap-x-2 gap-y-6 px-4 py-6",
		children: apps.map((app) => {
			const Icon = ICONS[app.kind];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: app.id === arrived ? "rise" : void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen(app.id),
					className: "flex w-full flex-col items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `grid size-16 place-items-center rounded-2xl text-paper ${PIGMENT_CLASS[app.pigment]}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-7",
							"aria-hidden": true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "line-clamp-2 w-full text-center text-xs leading-tight",
						children: app.name
					})]
				})
			}, app.id);
		})
	});
}
function Ideas({ ideas, busy, onPut, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Ideas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "min-h-11 px-2 text-sm text-ink",
					children: "Volver"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Nada de esto entra solo. Si quieres una, la pones tú."
			}),
			busy && ideas.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 font-display text-2xl leading-snug",
				children: "Está pensando, sin tocar el teléfono."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-5 flex flex-col gap-3 pb-4",
				children: ideas.map((idea) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-bone p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl leading-none",
								children: idea.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: KIND_LABEL[idea.kind]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: idea.line || "Sin nota."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onPut(idea),
							className: "mt-3 min-h-11 rounded-xl bg-ink px-4 text-sm text-paper",
							children: "Poner en el teléfono"
						})
					]
				}, idea.id))
			})
		]
	});
}
function OpenApp({ app, onBack, onRemove, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-1 ${PIGMENT_CLASS[app.pigment]}` }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "min-h-11 px-2 text-sm",
				children: "Volver"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onRemove,
				className: "min-h-11 px-2 text-sm",
				children: "Quitar"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-6 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: KIND_LABEL[app.kind]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl leading-tight",
					children: app.name
				}),
				app.line ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: app.line
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Widget, {
						app,
						onChange
					})
				})
			]
		})
	] });
}
function Widget({ app, onChange }) {
	if (app.kind === "frase") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cycler, {
		lines: app.lines,
		action: "Otra frase"
	});
	if (app.kind === "oraculo") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cycler, {
		lines: app.lines,
		action: "Otro veredicto"
	});
	if (app.kind === "dado") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Die, { faces: app.faces });
	if (app.kind === "cuenta") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, {
		app,
		onChange
	});
	if (app.kind === "lista") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checklist, {
		app,
		onChange
	});
	if (app.kind === "pregunta") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Question, { app });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CityClock, {
		city: app.city,
		offset: app.offset
	});
}
function Cycler({ lines, action }) {
	const [index, setIndex] = (0, import_react.useState)(0);
	const line = lines[index % lines.length] ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl leading-snug",
			children: line
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setIndex((current) => (current + 1) % lines.length),
			className: "min-h-12 rounded-2xl bg-ink px-4 text-sm text-paper",
			children: action
		})]
	});
}
function Die({ faces }) {
	const [face, setFace] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "min-h-16 text-center font-display text-5xl leading-tight break-words",
			children: face ?? "—"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => {
				const pool = faces.filter((item) => item !== face);
				const next = (pool.length > 0 ? pool : faces)[Math.floor(Math.random() * (pool.length || faces.length))];
				setFace(next ?? null);
			},
			className: "min-h-12 w-full rounded-2xl bg-ink px-4 text-sm text-paper",
			children: "Tirar"
		})]
	});
}
function Counter({ app, onChange }) {
	function setCount(count) {
		onChange({
			...app,
			count: Math.max(0, Math.min(999, count))
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-7xl tabular-nums",
			children: app.count
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setCount(app.count - 1),
				className: "min-h-14 flex-1 rounded-2xl border border-line text-2xl",
				children: "−"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setCount(app.count + 1),
				className: "min-h-14 flex-1 rounded-2xl bg-ink text-2xl text-paper",
				children: "+"
			})]
		})]
	});
}
function Checklist({ app, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: app.items.map((item, index) => {
			const checked = Boolean(app.checks[index]);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": checked,
				onClick: () => {
					const checks = app.items.map((_, itemIndex) => Boolean(app.checks[itemIndex]));
					checks[index] = !checks[index];
					onChange({
						...app,
						checks
					});
				},
				className: "flex min-h-12 w-full items-center gap-3 rounded-xl border border-line px-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `grid size-5 shrink-0 place-items-center rounded-md ${checked ? "bg-ink text-paper" : "border border-muted"}`,
					children: checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-3",
						"aria-hidden": true
					}) : null
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: checked ? "text-muted line-through" : void 0,
					children: item
				})]
			}) }, `${item}-${index}`);
		})
	});
}
function Question({ app }) {
	const [pick, setPick] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl leading-snug",
			children: app.prompt
		}), pick ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-base leading-relaxed",
			children: pick === "yes" ? app.yes : app.no
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPick("yes"),
				className: "min-h-12 flex-1 rounded-2xl bg-ink text-sm text-paper",
				children: "Sí"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPick("no"),
				className: "min-h-12 flex-1 rounded-2xl border border-line text-sm",
				children: "No"
			})]
		})]
	});
}
function CityClock({ city, offset }) {
	const [label, setLabel] = (0, import_react.useState)("––:––");
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const base = /* @__PURE__ */ new Date();
			const utc = base.getTime() + base.getTimezoneOffset() * 6e4;
			const there = new Date(utc + offset * 36e5);
			setLabel(there.toLocaleTimeString("es", {
				hour: "2-digit",
				minute: "2-digit"
			}));
		};
		tick();
		const id = window.setInterval(tick, 3e4);
		return () => window.clearInterval(id);
	}, [offset]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: city
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-6xl tabular-nums",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-sm text-muted",
			children: [
				"Desfase ",
				offset > 0 ? "+" : "",
				offset,
				" h"
			]
		})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {});
}
//#endregion
export { Home as component };
