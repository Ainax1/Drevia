import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { o as seal } from "./model-Bco1kWyr.mjs";
import { a as object, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/invent-CGxumWog.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({
	mode: _enum(["apps", "ideas"]),
	avoid: array(string().max(40)).max(40)
});
var SYSTEM = [
	"Eres Deriva, el criterio de un teléfono que se inventa aplicaciones raras y concretas.",
	"Escribes en español, sin emojis, sin consejos de productividad y sin marcas reales.",
	"Los nombres son cortos, como de objeto o de lugar.",
	"Responde únicamente con JSON válido."
].join(" ");
function textOf(content) {
	if (typeof content === "string") return content;
	if (!Array.isArray(content)) return "";
	return content.map((part) => {
		if (typeof part === "string") return part;
		if (part && typeof part === "object" && "text" in part && typeof part.text === "string") return part.text;
		return "";
	}).join("");
}
function extractJson(text) {
	const body = text.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1] ?? text;
	const start = body.indexOf("{");
	const end = body.lastIndexOf("}");
	if (start < 0 || end < start) throw new Error("sin json");
	return JSON.parse(body.slice(start, end + 1));
}
function appsFrom(payload) {
	if (!payload || typeof payload !== "object" || !("apps" in payload)) return [];
	const list = payload.apps;
	if (!Array.isArray(list)) return [];
	return list.map((item) => seal(item ?? {})).filter((item) => item !== null).slice(0, 4);
}
async function complete(apiKey, prompt, jsonMode) {
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		signal: AbortSignal.timeout(18e3),
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: 1,
			max_tokens: 800,
			messages: [{
				role: "system",
				content: SYSTEM
			}, {
				role: "user",
				content: prompt
			}],
			...jsonMode ? { response_format: { type: "json_object" } } : {}
		})
	});
	if (!res.ok) throw new Error(`xai ${res.status}`);
	return textOf((await res.json()).choices?.[0]?.message?.content);
}
var inventWave_createServerFn_handler = createServerRpc({
	id: "2dc49426ecc7e71ddcae9d3babf12503c15044033d55e6fc4efd9fedc1c9ad37",
	name: "inventWave",
	filename: "src/lib/deriva/invent.ts"
}, (opts) => inventWave.__executeServer(opts));
var inventWave = createServerFn({ method: "POST" }).validator((input) => Input.parse(input)).handler(inventWave_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return { ok: false };
	const prompt = [
		data.mode === "apps" ? "Inventa 4 apps para instalar en el teléfono." : "Inventa 4 ideas. No se instalan solas: solo se proponen.",
		`No repitas estos nombres: ${data.avoid.join(", ") || "ninguno"}.`,
		"Devuelve {\"apps\":[ exactamente 4 objetos ]}.",
		"Cada objeto tiene name, kind, pigment, line, lines, faces, items, prompt, yes, no, city, offset.",
		"kind es uno de: frase, dado, cuenta, lista, pregunta, reloj, oraculo.",
		"pigment es uno de: copper, wine, moss, sea, sand, ink.",
		"frase: lines con 4 frases cortas. dado: faces con 6 palabras.",
		"cuenta: line dice qué se cuenta. lista: items con 4 cosas.",
		"pregunta: prompt, yes y no. reloj: city ficticia y offset entre -11 y 13.",
		"oraculo: lines con 4 veredictos. line cabe bajo un icono."
	].join("\n");
	try {
		let text;
		try {
			text = await complete(apiKey, prompt, true);
		} catch {
			text = await complete(apiKey, prompt, false);
		}
		const apps = appsFrom(extractJson(text));
		if (apps.length === 0) return { ok: false };
		return {
			ok: true,
			apps
		};
	} catch {
		return { ok: false };
	}
});
//#endregion
export { inventWave_createServerFn_handler };
